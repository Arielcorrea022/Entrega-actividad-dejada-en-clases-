<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_cliente = $_POST['id_cliente'];
    $fecha = $_POST['fecha'];
    $total = $_POST['total'];

    // Verificar si el cliente existe antes de agregar el pedido
    $sql_cliente = "SELECT * FROM clientes WHERE id_cliente = ?";
    $stmt_cliente = $conn->prepare($sql_cliente);
    $stmt_cliente->bind_param("i", $id_cliente);
    $stmt_cliente->execute();
    $result_cliente = $stmt_cliente->get_result();

    if ($result_cliente->num_rows > 0) {
        // El cliente existe, insertar el pedido
        $sql = "INSERT INTO pedidos (id_cliente, fecha, total) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isd", $id_cliente, $fecha, $total);

        if ($stmt->execute()) {
            echo "<div style='text-align: center; margin-top: 20px;'>
                    <h2 style='color: green;'>Pedido agregado exitosamente</h2>
                    <a href='pedidos.php' style='text-decoration: none; background-color: #28a745; color: white; padding: 10px 20px; border-radius: 5px;'>Volver a Pedidos</a>
                  </div>";
        } else {
            echo "<div style='text-align: center; margin-top: 20px;'>
                    <h2 style='color: red;'>Error al agregar pedido: {$stmt->error}</h2>
                    <a href='pedidos.php' style='text-decoration: none; background-color: #dc3545; color: white; padding: 10px 20px; border-radius: 5px;'>Volver a Pedidos</a>
                  </div>";
        }

        $stmt->close();
    } else {
        // El cliente no existe
        echo "<div style='text-align: center; margin-top: 20px;'>
                <h2 style='color: red;'>El cliente no existe. Por favor, verifica el ID.</h2>
                <a href='pedidos.php' style='text-decoration: none; background-color: #dc3545; color: white; padding: 10px 20px; border-radius: 5px;'>Volver a Pedidos</a>
              </div>";
    }

    $stmt_cliente->close();
    $conn->close();
}

// Plantilla de diseño
include 'plantilla_procesamiento.php';
?>
