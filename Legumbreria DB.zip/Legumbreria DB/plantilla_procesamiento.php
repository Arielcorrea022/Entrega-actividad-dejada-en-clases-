<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legumbrería - Procesamiento</title>
    <!-- Enlace a Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Estilos personalizados -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }
        .container {
            margin-top: 50px;
            text-align: center;
        }
        .btn {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Mensajes dinámicos -->
        <?php
        if (isset($status) && $status == "success") {
            echo "<div class='alert alert-success' role='alert'>$message</div>";
        } elseif (isset($status) && $status == "error") {
            echo "<div class='alert alert-danger' role='alert'>$message</div>";
        }
        ?>
        <a href="index.php" class="btn btn-success">Volver al Inicio</a>
    </div>
</body>
</html>
