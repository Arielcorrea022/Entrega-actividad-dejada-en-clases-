<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Pedidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center text-success">Gestión de Pedidos</h1>
        <form method="POST" action="agregar_pedido.php" class="border p-4 bg-light shadow-sm">
            <div class="mb-3">
                <label for="id_cliente" class="form-label">ID Cliente:</label>
                <input type="number" class="form-control" id="id_cliente" name="id_cliente" required>
            </div>
            <div class="mb-3">
                <label for="fecha" class="form-label">Fecha:</label>
                <input type="date" class="form-control" id="fecha" name="fecha" required>
            </div>
            <div class="mb-3">
                <label for="total" class="form-label">Total:</label>
                <input type="number" step="0.01" class="form-control" id="total" name="total" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Crear Pedido</button>
        </form>

        <h2 class="mt-5">Lista de Pedidos</h2>
        <?php
        include 'db_connection.php';
        $sql = "SELECT * FROM pedidos";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<table class='table table-striped'>";
            echo "<thead><tr><th>ID</th><th>ID Cliente</th><th>Fecha</th><th>Total</th></tr></thead><tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['id_pedido']}</td><td>{$row['id_cliente']}</td><td>{$row['fecha']}</td><td>{$row['total']}</td></tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p>No hay pedidos registrados.</p>";
        }
        ?>
    </div>
</body>
</html>
