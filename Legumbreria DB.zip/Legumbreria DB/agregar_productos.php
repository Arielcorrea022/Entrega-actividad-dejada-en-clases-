<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $valor_unitario = $_POST['valor_unitario'];
    $cantidad_stock = $_POST['cantidad_stock'];
    $fecha_vencimiento = !empty($_POST['fecha_vencimiento']) ? $_POST['fecha_vencimiento'] : NULL;

    // Inserción del producto en la base de datos
    $sql = "INSERT INTO productos (nombre, valor_unitario, cantidad_stock, fecha_vencimiento) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdid", $nombre, $valor_unitario, $cantidad_stock, $fecha_vencimiento);

    if ($stmt->execute()) {
        echo "<div style='text-align: center; margin-top: 20px;'>
                <h2 style='color: green;'>Producto agregado exitosamente</h2>
                <a href='productos.php' style='text-decoration: none; background-color: #28a745; color: white; padding: 10px 20px; border-radius: 5px;'>Volver a Productos</a>
              </div>";
    } else {
        echo "<div style='text-align: center; margin-top: 20px;'>
                <h2 style='color: red;'>Error al agregar producto: {$stmt->error}</h2>
                <a href='productos.php' style='text-decoration: none; background-color: #dc3545; color: white; padding: 10px 20px; border-radius: 5px;'>Volver a Productos</a>
              </div>";
    }

    $stmt->close();
    $conn->close();
}

// Plantilla de diseño
include 'plantilla_procesamiento.php';
?>
