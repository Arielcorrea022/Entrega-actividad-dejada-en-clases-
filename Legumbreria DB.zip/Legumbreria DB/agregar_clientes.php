<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $categoria_id = $_POST['categoria_id']; // Tomar el valor del formulario

    // Si la categoría está vacía o no válida, asignamos NULL
    $categoria_id = !empty($categoria_id) ? $categoria_id : NULL;

    $fecha_registro = date("Y-m-d"); // Fecha actual

    $sql = "INSERT INTO clientes (nombre, categoria_id, fecha_registro) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sis", $nombre, $categoria_id, $fecha_registro);

    if ($stmt->execute()) {
        echo "Cliente agregado exitosamente.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}

// Plantilla de diseño
include 'plantilla_procesamiento.php';
?>
