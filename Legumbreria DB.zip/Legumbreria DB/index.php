<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legumbrería FRUTY FRUTY </title>
    <!-- Enlace a Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Enlace a Font Awesome para íconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Enlace a tu propio archivo de estilos -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Barra de navegación -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success shadow">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><i class="fas fa-leaf"></i> Legumbrería</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="clientes.php"><i class="fas fa-users"></i> Clientes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="productos.php"><i class="fas fa-box"></i> Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pedidos.php"><i class="fas fa-shopping-cart"></i> Pedidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auditoria.php"><i class="fas fa-file-alt"></i> Auditoría</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contenido principal -->
    <header class="text-center bg-light py-5">
        <h1 class="display-3 text-success">¡Bienvenido a Legumbrería FRUTY FRUTY!</h1>
        <p class="lead">La mejor solución para gestionar tus clientes, productos y pedidos.</p>
        <a href="clientes.php" class="btn btn-success btn-lg shadow">Comienza Ahora</a>
    </header>

    <!-- Sección de características -->
    <section class="container text-center my-5">
        <h2 class="text-success">¿Por qué elegirnos?</h2>
        <div class="row mt-4">
            <div class="col-md-4">
                <i class="fas fa-users fa-3x text-success mb-3"></i>
                <h5>Gestión de Clientes</h5>
                <p>Registra, actualiza y consulta a tus clientes fácilmente.</p>
            </div>
            <div class="col-md-4">
                <i class="fas fa-box fa-3x text-success mb-3"></i>
                <h5>Control de Inventario</h5>
                <p>Monitorea tu stock y productos con fechas de vencimiento.</p>
            </div>
            <div class="col-md-4">
                <i class="fas fa-shopping-cart fa-3x text-success mb-3"></i>
                <h5>Pedidos Simplificados</h5>
                <p>Gestiona y detalla tus pedidos de forma eficiente.</p>
            </div>
        </div>
    </section>

    <!-- Pie de página -->
    <footer class="bg-success text-white text-center py-3">
        <p>&copy; 2025 Legumbrería. Todos los derechos reservados.</p>
        <p><i class="fas fa-leaf"></i> Con amor por la naturaleza.</p>
    </footer>

    <!-- Enlace a Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
