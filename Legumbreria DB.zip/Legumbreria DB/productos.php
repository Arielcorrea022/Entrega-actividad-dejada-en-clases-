<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos</title>
    <!-- Enlace a Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Estilo personalizado -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        h1, h2 {
            text-align: center;
            color: #2e7d32; /* Verde oscuro */
            margin-bottom: 30px;
        }
        .form-container {
            max-width: 600px;
            margin: 0 auto;
        }
        table {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Título principal -->
        <h1>Gestión de Productos</h1>

        <!-- Formulario para agregar productos -->
        <div class="form-container bg-light p-4 shadow-sm border rounded">
            <form method="POST" action="agregar_productos.php">
                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre:</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Ingresa el nombre del producto" required>
                </div>
                <div class="mb-3">
                    <label for="valor_unitario" class="form-label">Valor Unitario:</label>
                    <input type="number" class="form-control" id="valor_unitario" name="valor_unitario" placeholder="Ejemplo: 10.50" required>
                </div>
                <div class="mb-3">
                    <label for="cantidad_stock" class="form-label">Cantidad en Stock:</label>
                    <input type="number" class="form-control" id="cantidad_stock" name="cantidad_stock" placeholder="Ejemplo: 100" required>
                </div>
                <div class="mb-3">
                    <label for="fecha_vencimiento" class="form-label">Fecha de Vencimiento:</label>
                    <input type="date" class="form-control" id="fecha_vencimiento" name="fecha_vencimiento">
                </div>
                <button type="submit" class="btn btn-success w-100">Agregar Producto</button>
            </form>
        </div>

        <!-- Tabla de productos -->
        <h2 class="mt-5">Lista de Productos</h2>
        <?php
        include 'db_connection.php';

        // Consultar los productos de la base de datos
        $sql = "SELECT * FROM productos";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table class='table table-striped table-hover'>";
            echo "<thead class='table-success'><tr><th>ID</th><th>Nombre</th><th>Valor</th><th>Stock</th><th>Vencimiento</th></tr></thead><tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id_producto']}</td>
                        <td>{$row['nombre']}</td>
                        <td>{$row['valor_unitario']}</td>
                        <td>{$row['cantidad_stock']}</td>
                        <td>{$row['fecha_vencimiento']}</td>
                      </tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<div class='alert alert-warning mt-4' role='alert'>No hay productos registrados.</div>";
        }

        $conn->close(); // Cerrar la conexión
        ?>
    </div>

    <!-- Enlace a Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

